import json
import os
from datetime import datetime

HISTORY_FILE = os.path.expanduser("~/.dedsec_reputation_history.json")

def load_history():
    """Загружает историю проверок из файла"""
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            return json.load(f)
    return {}

def save_history(history):
    """Сохраняет историю в файл"""
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)

def calculate(target, results_list, target_type):
    """
    Определяет репутацию цели с учётом истории
    """
    data_str = " ".join(results_list).lower()
    history = load_history()

    # Если цель уже есть в истории
    if target in history:
        old_data = history[target]
        last_reputation = old_data.get("reputation", "НЕЙТРАЛ")
        last_time = old_data.get("last_seen", "неизвестно")
    else:
        old_data = {}
        last_reputation = None

    # ---- АНАЛИЗ ТЕКУЩИХ ДАННЫХ ----
    score_negative = 0
    score_positive = 0

    # Негативные факторы
    if "террорист" in data_str or "santsligon" in data_str:
        score_negative += 4
    if "анарх" in data_str:
        score_negative += 3
    if "преступник" in data_str:
        score_negative += 2
    if "нарушитель" in data_str:
        score_negative += 1
    if "оружие" in data_str:
        score_negative += 2
    if "взрывчатк" in data_str:
        score_negative += 3

    # Позитивные факторы
    if "защитник" in data_str:
        score_positive += 2
    if "мститель" in data_str:
        score_positive += 3
    if "помощь" in data_str:
        score_positive += 1

    # ---- ОПРЕДЕЛЕНИЕ ТЕКУЩЕЙ РЕПУТАЦИИ ----
    if score_negative > score_positive:
        if score_negative >= 7:
            level = 4
            name = "АНАРХИСТ"
            color = "\033[91m"
        elif score_negative >= 5:
            level = 3
            name = "ТЕРРОРИСТ"
            color = "\033[91m"
        elif score_negative >= 3:
            level = 2
            name = "ПРЕСТУПНИК"
            color = "\033[91m"
        else:
            level = 1
            name = "НАРУШИТЕЛЬ"
            color = "\033[91m"
        camp = "🔴 ВРАГ СИСТЕМЫ"
    elif score_positive > score_negative:
        if score_positive >= 5:
            level = 3
            name = "МСТИТЕЛЬ"
            color = "\033[92m"
        elif score_positive >= 3:
            level = 2
            name = "ЗАЩИТНИК"
            color = "\033[92m"
        else:
            level = 1
            name = "ГРАЖДАНИН"
            color = "\033[92m"
        camp = "🟢 СОЮЗНИК"
    else:
        level = 0
        name = "НЕЙТРАЛ"
        color = "\033[93m"
        camp = "🟡 НЕ ОПРЕДЕЛЕНО"

    # ---- СРАВНЕНИЕ С ПРОШЛЫМ ----
    change = ""
    if last_reputation:
        if last_reputation != name:
            change = f" ⚡ ИЗМЕНИЛОСЬ: было {last_reputation}"
            if "ВРАГ" in camp and "СОЮЗНИК" in history[target].get("camp", ""):
                change += " 🔻 СТАЛ ОПАСНЕЕ"
            elif "СОЮЗНИК" in camp and "ВРАГ" in history[target].get("camp", ""):
                change += " 🔺 СТАЛ ЛУЧШЕ"

    # ---- СОХРАНЕНИЕ В ИСТОРИЮ ----
    history[target] = {
        "last_seen": datetime.now().isoformat(),
        "type": target_type,
        "reputation": name,
        "camp": camp,
        "level": level,
        "data_preview": data_str[:200]  # первые 200 символов для анализа
    }
    save_history(history)

    # Финальный вывод
    result = f"{camp} | {color}{name} (Уровень {level})\033[0m{change}"
    return result

