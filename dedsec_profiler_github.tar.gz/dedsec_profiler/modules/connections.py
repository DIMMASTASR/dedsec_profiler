import requests
from utils.helpers import green, yellow

def get_vk_friends(user_id):
    """Пытается получить друзей VK (только если открытый профиль)"""
    try:
        r = requests.get(f"https://vk.com/friends?id={user_id}", timeout=5)
        if r.status_code == 200:
            return True
    except:
        pass
    return False

def scan(target):
    """Анализ связей цели"""
    print(green("\n[*] CONNECTIONS: Analyzing social connections..."))
    results = []

    # Если цель — ID ВК
    if "vk.com" in target or "id" in target:
        user_id = target.split("/")[-1]
        if get_vk_friends(user_id):
            msg = "[+] Target has visible friends (open VK profile)"
            print(green(msg))
            results.append(msg)
        else:
            print(yellow("[?] No public friend data"))

    # Общий поиск связей
    results.append("[+] Connection analysis: basic only (API required for deep)")
    return results
