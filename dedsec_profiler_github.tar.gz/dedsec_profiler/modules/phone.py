import requests
from utils.helpers import green, red, yellow

def scan(phone):
    print(f"\n[*] Searching for phone: {phone}")
    results = []

    # Telegram
    try:
        r = requests.get(f"https://t.me/{phone}", timeout=5)
        if r.status_code == 200 and "tgme_page" in r.text:
            msg = f"[+] Telegram: https://t.me/{phone}"
            print(green(msg))
            results.append(msg)
    except:
        pass

    # VK
    try:
        r = requests.get(f"https://vk.com/phone/{phone}", timeout=5, allow_redirects=True)
        if "profile" in r.url:
            msg = f"[+] VK: {r.url}"
            print(green(msg))
            results.append(msg)
    except:
        pass

    # Avito
    msg = f"[+] Avito: https://www.avito.ru/items?q={phone}"
    print(green(msg))
    results.append(msg)

    # Google
    msg = f"[+] Google: https://www.google.com/search?q={phone}"
    print(green(msg))
    results.append(msg)

    return results
