import re
from utils.helpers import green, yellow

def extract_name(data_str):
    """Пытается извлечь имя из текста"""
    # Поиск русских имён (Имя Фамилия)
    names = re.findall(r'[А-Я][а-я]+ [А-Я][а-я]+', data_str)
    return names[0] if names else None

def scan(results_list):
    """Извлечение персональных данных"""
    print(green("\n[*] PERSONAL: Extracting personal info..."))
    results = []
    data_str = " ".join(results_list)

    # Поиск имени
    name = extract_name(data_str)
    if name:
        msg = f"[+] Name: {name}"
        print(green(msg))
        results.append(msg)

    # Поиск возраста
    ages = re.findall(r'\b(\d{2})\s*(лет|год|age)', data_str)
    if ages:
        msg = f"[+] Age: {ages[0][0]}"
        print(green(msg))
        results.append(msg)

    # Поиск интересов
    interests_keywords = ["хакер", "hack", "coding", "music", "cars", "games", "панк", "анарх"]
    found = []
    for word in interests_keywords:
        if word in data_str.lower():
            found.append(word)
    if found:
        msg = f"[+] Interests: {', '.join(found)}"
        print(green(msg))
        results.append(msg)
    else:
        print(yellow("[?] No personal data extracted"))

    return results
