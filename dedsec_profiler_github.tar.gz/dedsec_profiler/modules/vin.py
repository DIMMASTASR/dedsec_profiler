import requests
from utils.helpers import green, red, yellow

def scan(vin):
    print(f"\n[*] Analyzing VIN: {vin}")
    results = []

    # NHTSA decoder
    try:
        r = requests.get(f"https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/{vin}?format=json", timeout=10)
        if r.status_code == 200:
            data = r.json()
            print(green("[+] NHTSA VIN decode:"))
            for item in data.get("Results", []):
                if item.get("Value"):
                    line = f"  {item.get('Variable')}: {item.get('Value')}"
                    print(green(line))
                    results.append(line)
    except Exception as e:
        print(yellow(f"[?] NHTSA error: {e}"))

    return results
