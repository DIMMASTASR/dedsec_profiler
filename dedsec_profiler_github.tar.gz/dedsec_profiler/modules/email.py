import requests
from utils.helpers import green, red, yellow

def scan(email):
    print(f"\n[*] Checking email: {email}")
    results = []

    # Проверка через haveibeenpwned
    try:
        headers = {
            "User-Agent": "hello_friend OSINT tool",
            "hibp-api-key": ""  # если есть ключ, вставь сюда
        }
        r = requests.get(
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}",
            headers=headers,
            timeout=5
        )
        if r.status_code == 200:
            breaches = r.json()
            breach_names = [b['Name'] for b in breaches]
            msg = f"[!] Email found in breaches: {', '.join(breach_names)}"
            print(red(msg))
            results.append(msg)
        elif r.status_code == 404:
            msg = "[+] No breaches found (via HIBP)"
            print(green(msg))
            results.append(msg)
        elif r.status_code == 401:
            msg = "[!] HIBP requires paid subscription. Get it at haveibeenpwned.com/API/Key"
            print(yellow(msg))
            results.append(msg)
        else:
            msg = f"[?] HIBP returned status: {r.status_code}"
            print(yellow(msg))
            results.append(msg)
    except Exception as e:
        msg = f"[?] HIBP check failed: {str(e)[:50]}"
        print(yellow(msg))
        results.append(msg)

    return results
