import requests
import subprocess
import re
from utils.helpers import green, yellow

def get_ip_location(ip):
    """Определяет примерное местоположение по IP"""
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        if r.status_code == 200:
            data = r.json()
            if data.get("status") == "success":
                city = data.get("city", "unknown")
                country = data.get("country", "unknown")
                return f"{city}, {country}"
    except:
        pass
    return None

def get_gps_from_photo(path):
    """Извлекает GPS из EXIF фото"""
    try:
        result = subprocess.run(["exiftool", "-GPSLatitude", "-GPSLongitude", path], 
                                capture_output=True, text=True)
        lat = re.search(r"GPSLatitude\s+:\s+(.+)", result.stdout)
        lon = re.search(r"GPSLongitude\s+:\s+(.+)", result.stdout)
        if lat and lon:
            coords = f"{lat.group(1).strip()},{lon.group(1).strip()}"
            maps_url = f"https://www.google.com/maps?q={coords}"
            return maps_url
    except:
        pass
    return None

def scan(target):
    """Основная функция модуля"""
    print(green("\n[*] GEO: Analyzing location data..."))
    results = []

    # Если цель похожа на IP
    if target.replace(".", "").isdigit() and target.count(".") == 3:
        location = get_ip_location(target)
        if location:
            msg = f"[+] IP location: {location}"
            print(msg)
            results.append(msg)
        else:
            print(yellow("[?] Could not determine IP location"))

    # Если цель похожа на путь к фото
    elif target.endswith(('.jpg', '.jpeg', '.png', '.gif')):
        gps = get_gps_from_photo(target)
        if gps:
            msg = f"[+] GPS from photo: {gps}"
            print(msg)
            results.append(msg)
        else:
            print(yellow("[?] No GPS data in photo"))

    return results
