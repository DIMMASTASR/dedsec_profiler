import requests
from utils.helpers import green, yellow

def scan(target):
    """Поиск архивных данных"""
    print(green("\n[*] HISTORY: Checking historical data..."))
    results = []

    # Archive.org для доменов
    if "." in target and " " not in target and not target.startswith("+"):
        archive_url = f"https://web.archive.org/web/*/{target}"
        msg = f"[+] Archive.org: {archive_url}"
        print(green(msg))
        results.append(msg)

    # Поиск старых аккаунтов (упрощённо)
    msg = "[+] Historical accounts: use google dorks: 'inurl:{}'".format(target)
    print(yellow(msg))
    results.append(msg)

    return results
