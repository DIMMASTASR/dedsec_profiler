import requests
from utils.helpers import green, red, yellow

# Расширенный список сайтов
SITES = {
    "VK": "https://vk.com/{}",
    "Instagram": "https://instagram.com/{}",
    "Telegram": "https://t.me/{}",
    "Twitter": "https://twitter.com/{}",
    "GitHub": "https://github.com/{}",
    "YouTube": "https://youtube.com/@{}",
    "TikTok": "https://tiktok.com/@{}",
    "Reddit": "https://reddit.com/user/{}",
    "Steam": "https://steamcommunity.com/id/{}",
    "Twitch": "https://twitch.tv/{}",
    "Pinterest": "https://pinterest.com/{}",
    "Spotify": "https://open.spotify.com/user/{}",
    "Snapchat": "https://snapchat.com/add/{}",
    "Discord": "https://discord.com/users/{}",
    "GitLab": "https://gitlab.com/{}",
    "Medium": "https://medium.com/@{}",
    "DeviantArt": "https://deviantart.com/{}",
    "Flickr": "https://flickr.com/people/{}",
    "Patreon": "https://patreon.com/{}",
    "SoundCloud": "https://soundcloud.com/{}",
    "Bandcamp": "https://bandcamp.com/{}",
    "About.me": "https://about.me/{}",
    "Keybase": "https://keybase.io/{}",
    "Gravatar": "https://en.gravatar.com/{}",
    "WordPress": "https://{}.wordpress.com",
    "Blogger": "https://{}.blogspot.com",
    "Tumblr": "https://{}.tumblr.com",
    "LiveJournal": "https://{}.livejournal.com",
    "Pastebin": "https://pastebin.com/u/{}",
    "HackerNews": "https://news.ycombinator.com/user?id={}",
    "ProductHunt": "https://producthunt.com/@{}",
    "AngelList": "https://angel.co/u/{}",
    "Crunchbase": "https://crunchbase.com/person/{}",
    "LinkedIn": "https://linkedin.com/in/{}",
    "Goodreads": "https://goodreads.com/{}",
    "IMDb": "https://imdb.com/name/{}",
    "Last.fm": "https://last.fm/user/{}",
    "Vimeo": "https://vimeo.com/{}",
    "OK.ru": "https://ok.ru/{}",
    "Мой Мир": "https://my.mail.ru/{}",
}

def scan(target):
    """Поиск по нику во всех соцсетях"""
    print(green(f"\n[*] SOCIAL: Searching for nickname: {target}"))
    results = []
    headers = {"User-Agent": "Mozilla/5.0"}

    for site, url_template in SITES.items():
        url = url_template.format(target)
        try:
            r = requests.get(url, headers=headers, timeout=3, allow_redirects=True)
            if r.status_code == 200:
                msg = f"[+] {site}: {url}"
                print(green(msg))
                results.append(msg)
            elif r.status_code == 404:
                print(red(f"[-] {site}: not found"))
            else:
                print(yellow(f"[?] {site}: {r.status_code}"))
        except Exception as e:
            print(red(f"[!] Error checking {site}: {str(e)[:50]}"))

    return results
