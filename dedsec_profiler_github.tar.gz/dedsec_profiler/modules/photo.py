import os
import subprocess
from utils.helpers import green, red, yellow

def scan(path):
    if not os.path.exists(path):
        print(red("[!] File not found"))
        return []

    print(f"\n[*] Analyzing photo: {path}")
    results = []

    # Метаданные через exiftool
    try:
        print(green("[*] EXIF data:"))
        result = subprocess.run(["exiftool", path], capture_output=True, text=True)
        for line in result.stdout.split("\n"):
            if line.strip():
                print(f"  {line}")
                results.append(line)
    except FileNotFoundError:
        print(yellow("[!] exiftool not installed. Install with: sudo apt install exiftool"))
        results.append("[!] exiftool not available")

    # Поиск по картинке (открываем ссылки)
    print(green("\n[*] Image search links:"))
    yandex_url = f"https://yandex.ru/images/search?rpt=imageview&url=file://{path}"
    google_url = f"https://images.google.com/searchbyimage?image_url=file://{path}"
    print(f"  Yandex: {yandex_url}")
    print(f"  Google: {google_url}")
    results.append(f"Yandex: {yandex_url}")
    results.append(f"Google: {google_url}")

    return results
