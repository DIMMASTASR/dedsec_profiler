from utils.helpers import green, red, yellow

def scan(results_list):
    """Анализ угроз на основе已有的 результатов"""
    print(green("\n[*] THREATS: Analyzing threat level..."))
    results = []
    data_str = " ".join(results_list).lower()

    threat_keywords = [
        "террорист", "terror", "santsligon", "экстремист",
        "игил", "isis", "взрывчатк", "оружие", "attack",
        "убить", "kill", "бомб", "бомба", "насилие"
    ]

    found = []
    for word in threat_keywords:
        if word in data_str:
            found.append(word)

    if found:
        msg = f"[!] POTENTIAL THREAT: keywords found: {', '.join(found)}"
        print(red(msg))
        results.append(msg)
    else:
        msg = "[+] No direct threats detected"
        print(green(msg))
        results.append(msg)

    return results
