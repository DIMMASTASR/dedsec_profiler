import subprocess
import socket
from utils.helpers import green, red, yellow

def scan(domain):
    print(f"\n[*] Analyzing domain: {domain}")
    results = []

    # Whois
    try:
        print(green("[*] WHOIS:"))
        result = subprocess.run(["whois", domain], capture_output=True, text=True, timeout=10)
        lines = result.stdout.split("\n")[:20]
        for line in lines:
            if line.strip():
                print(f"  {line}")
                results.append(line)
    except Exception as e:
        print(yellow(f"[!] Whois error: {e}"))

    # DNS записи
    try:
        print(green("\n[*] DNS records:"))
        for record in ["A", "MX", "NS", "TXT"]:
            result = subprocess.run(["dig", domain, record, "+short"], capture_output=True, text=True, timeout=5)
            if result.stdout.strip():
                print(f"  {record}: {result.stdout.strip()}")
                results.append(f"{record}: {result.stdout.strip()}")
    except Exception as e:
        print(yellow(f"[!] Dig error: {e}"))

    # IP адрес
    try:
        ip = socket.gethostbyname(domain)
        print(green(f"\n[*] IP: {ip}"))
        results.append(f"IP: {ip}")
    except Exception as e:
        print(red(f"[!] Could not resolve IP: {e}"))

    # Поддомены (через google)
    print(green("\n[*] Subdomain search (manual):"))
    google_url = f"https://www.google.com/search?q=site:{domain}"
    print(f"  Google: {google_url}")
    results.append(f"Subdomains: {google_url}")

    return results
