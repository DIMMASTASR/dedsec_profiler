import os

def print_banner():
    print(r"""
╔══════════════════════════════════╗
║     DEDSEC PROFILER v1.0         ║
║          FUCK ctOS                ║
║                                   ║
║        \033[91m     Ⓐ     \033[0m                 ║
║        \033[91m   ANARCHY   \033[0m               ║
║                                   ║
║   █▀▀ █▀▀█ █▀▀█ █▀▀ █▀▀█ █▀▀█   ║
║   █   █  █ █  █ █▀▀ █▄▄█ █  █   ║
║   ▀▀▀ ▀▀▀  ▀▀▀▀ ▀▀▀ █  █ ▀▀▀▀   ║
╚══════════════════════════════════╝
    """)

def save_report(filename, data):
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"TARGET: {data['target']}\n")
        f.write(f"TYPE: {data['type']}\n")
        f.write(f"TIME: {data['timestamp']}\n")
        f.write("-" * 50 + "\n")
        for item in data["results"]:
            f.write(f"{item}\n")
    print(f"[+] Report saved: {filename}")

def green(text):
    return f"\033[92m{text}\033[0m"

def red(text):
    return f"\033[91m{text}\033[0m"

def yellow(text):
    return f"\033[93m{text}\033[0m"
