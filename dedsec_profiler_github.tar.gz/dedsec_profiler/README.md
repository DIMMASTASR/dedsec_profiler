# Ⓐ dedsec_profiler — FUCK ctOS

**Анархический OSINT-профайлер в стиле DedSec**  
Ищет информацию по открытым источникам, оценивает репутацию, рисует красный Ⓐ.

> *«We are watching. ctOS can't see this. We can.»*

---

## 🧠 Возможности

| Модуль | Что делает |
|--------|------------|
| `nick` | Поиск по нику в 50+ соцсетях |
| `email` | Проверка email (HIBP, утечки) |
| `phone` | Поиск по номеру (TG, Avito, Google) |
| `photo` | EXIF-данные, GPS, поиск по картинкам |
| `domain` | WHOIS, DNS, IP, поддомены |
| `geo` | Геолокация по IP или фото |
| `social` | Глубокий поиск по соцсетям |
| `connections` | Связи, друзья, подписчики |
| `history` | Архивные данные, whois history |
| `threats` | Анализ угроз, экстремизм |
| `personal` | Имя, возраст, интересы |
| `risk` | Репутация в стиле Watch Dogs |

---

## ⚖️ Легальность

**Только открытые источники.**  
Никаких слитых баз, никакого доксинга.  
Всё, что умеет инструмент, можно найти вручную через браузер.

---

## 📦 Установка

```bash
git clone https://github.com/DIMMASTASR/dedsec_profiler.git
cd dedsec_profiler
pip install -r requirements.txt
python3 fuck_ctOS.py
