#!/usr/bin/env python3
import sys
import os
import signal
from datetime import datetime
from modules import nick, email, phone, photo, domain
from modules import geo, social, connections, history, threats, personal
from modules.risk import calculate
from utils.helpers import save_report, print_banner, green, red, yellow

# ---- ОБРАБОТЧИК CTRL+C ----
def signal_handler(sig, frame):
    print("\n")
    print(red(r"""
        ╔════════════════════════╗
        ║         Ⓐ               ║
        ║       ANARCHY           ║
        ║   SYSTEM INTERRUPTED    ║
        ║    FUCK ctOS. ALWAYS.   ║
        ╚════════════════════════╝
    """))
    print(red("\n[!] You killed the process. But the idea lives on.\n"))
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

def main():
    print_banner()
    print(green("\n[!] SYSTEM: DedSec OS — Anonymous. Always."))
    print(red("[!] WARNING: ctOS is watching. We watch back.\n"))

    target = input("[?] TARGET: ").strip()
    if not target:
        print(red("[!] No target. DedSec never sleeps, but you should try again."))
        return

    print(green("\n[1] PROFILE BY NICKNAME"))
    print(green("[2] PROFILE BY EMAIL"))
    print(green("[3] PROFILE BY PHONE"))
    print(green("[4] PROFILE BY PHOTO"))
    print(green("[5] PROFILE BY DOMAIN"))
    print(green("[6] DEEP PROFILE (ALL MODULES)"))
    print(red("[7] FUCK ctOS (EXIT)\n"))

    choice = input("[?] CHOOSE: ").strip()

    result_data = {
        "target": target,
        "type": choice,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "results": []
    }

    # ---- БАЗОВЫЕ МОДУЛИ ----
    if choice == "1":
        result_data["results"] = nick.scan(target)
    elif choice == "2":
        result_data["results"] = email.scan(target)
    elif choice == "3":
        result_data["results"] = phone.scan(target)
    elif choice == "4":
        result_data["results"] = photo.scan(target)
    elif choice == "5":
        result_data["results"] = domain.scan(target)

    # ---- ГЛУБОКИЙ ПРОФАЙЛ (ВСЕ МОДУЛИ) ----
    elif choice == "6":
        print(green("\n[ctOS] RUNNING DEEP PROFILE..."))

        # Запускаем все базовые модули
        result_data["results"].extend(nick.scan(target))
        result_data["results"].extend(email.scan(target))
        result_data["results"].extend(phone.scan(target))
        result_data["results"].extend(photo.scan(target))
        result_data["results"].extend(domain.scan(target))

        # Запускаем новые модули
        result_data["results"].extend(geo.scan(target))
        result_data["results"].extend(social.scan(target))

        # Специализированные модули с проверкой
        if 'vk.com' in target or 'id' in target:
            result_data["results"].extend(connections.scan(target))

        if '.' in target and ' ' not in target and '/' not in target:
            result_data["results"].extend(history.scan(target))

        result_data["results"].extend(threats.scan(result_data["results"]))
        result_data["results"].extend(personal.scan(result_data["results"]))

    elif choice == "7":
        print(red("\n[!] FUCK ctOS. Always."))
        return
    else:
        print(red("[!] Invalid choice. DedSec doesn't make mistakes. Try again."))
        return

    # Сохраняем отчёт
    os.makedirs("output", exist_ok=True)
    filename = f"output/{target}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    save_report(filename, result_data)
    print(green(f"\n[+] Report saved: {filename}"))

    # Риск-оценка
    risk_score = calculate(target, result_data["results"], choice)
    print(f"[ctOS] REPUTATION: {risk_score}")

    print(green("\n[!] ctOS can't see this. We can."))

if __name__ == "__main__":
    main()
